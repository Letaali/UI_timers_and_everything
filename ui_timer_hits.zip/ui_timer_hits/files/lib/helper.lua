function find_polymorphed_players()
    local nearby_polymorph = EntityGetWithTag( "polymorphed" ) or {};
    local polymorphed_players = {};
    for _,entity in pairs( nearby_polymorph ) do
        local game_stats = EntityGetFirstComponent( entity, "GameStatsComponent" );
        if game_stats ~= nil then
            if ComponentGetValue( game_stats, "is_player" ) == "1" then
                table.insert( polymorphed_players, entity );
            end
        end
    end
    return polymorphed_players;
end