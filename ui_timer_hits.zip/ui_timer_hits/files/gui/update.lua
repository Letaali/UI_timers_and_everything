print("[ui_timer] setting up GUI");
dofile_once( "data/scripts/lib/coroutines.lua" );
dofile_once( "mods/ui_timer_hits/files/lib/variables.lua" );
dofile_once( "mods/ui_timer_hits/files/lib/helper.lua" );
dofile_once( "data/scripts/lib/utilities.lua" );

local function truncate_long_string( str )
    if #str > 31 then
        str = str:sub( 0, 14 ).."..."..str:sub( -14 );
    end
    return str;
end

local function pattern_validation( value )
    local status,result = pcall( function() local s = string.format( value, 0,0,0,0,0,0,0,0 ); end );
    if status == false then
        return result;
    end 
    return true;
end

local function safe_string_format( format, ... )
    local s = "";
    local status,result = pcall( function(...)
        s = string.format( format, ... );
    end, ... );
    if status == false then return "err"; end 
    return s;
end

local gui = gui or GuiCreate();
local full_screen_width, full_screen_height = GuiGetScreenDimensions( gui );
GuiStartFrame( gui );
local screen_width, screen_height = GuiGetScreenDimensions( gui );

local gokiui = dofile_once( "mods/ui_timer_hits/files/mod_settings.lua" )( gui, 2, "ui_timer_hits", {

    { key="show_position", label = "Show Position", default = true, type = "boolean" },
    { key="show_depth", label = "Show Depth", default = true, type = "boolean" },
    { key="show_orbs_needed", label = "Show Orbs Needed", default = true, type = "boolean" },
    { key="show_world", label = "Show World", default = true, type = "boolean" },
    { key="show_ghost", label = "Show Ghost State", default = true, type = "boolean" },
    { key="show_time", label = "Show Time", default = true, type = "boolean" },
    { key="show_hits", label = "Show Hits", default = true, type = "boolean" },
    { key="show_hit_message", label = "Log Hits", default = false, type = "boolean" },
    { key="include_environmental_hits", label = "Include Environmental Damage Hits", default = true, type = "boolean" },
    { key="include_negative_damage", label = "Include Negative Damage Hits", default = false, type = "boolean" },
    { key="include_self_damage_hits", label = "Include Self Damage Hits", default = true, type = "boolean" },
    { key="include_polymorphed_hits", label = "Include Polymorph Damage Hits", default = true, type = "boolean" },
    { key="show_while_in_inventory", label = "Show In Inventory", default = true, type = "boolean" },

    { key="play_sound_on_hit", label = "Play Sound on Hit", default = true, type = "boolean" },
    { key="sound_volume", label = "Sound Volume", default = 10, type = "range", type_data = { min = 0, max = 20, value_callback = function( value ) return math.floor( value + 0.5 ); end } },
    { key="time_between_sounds", label = "Time Between Sounds", default = 15, type = "range", type_data = { min = 1, max = 120, value_callback = function( value ) return math.floor( value + 0.5 ); end } },

    { key="visibility", label = "Visibility", default = 1.0, type = "range", type_data = { min = 0.01, max = 1.0, text_callback = function( value ) return math.floor( value * 100 ).."%"; end } },
    { key="gui_x", label = "X", default = 24, type = "range", type_data = { min = 0, max = screen_width, value_callback = function( value ) return math.floor( value + 0.5 ); end } },
    { key="gui_y", label = "Y", default = 39, type = "range", type_data = { min = 0, max = screen_height, value_callback = function( value ) return math.floor( value + 0.5 ); end } },
    { key="inventory_gui_x", label = "Inventory X", default = 24, type = "range", type_data = { min = 0, max = screen_width, value_callback = function( value ) return math.floor( value + 0.5 ); end } },
    { key="inventory_gui_y", label = "Inventory Y", default = 350, type = "range", type_data = { min = 0, max = screen_width, value_callback = function( value ) return math.floor( value + 0.5 ); end } },
    { key="position_string", label = "Position String", default = "X %.2f", type = "input", validation_callback = pattern_validation },
    { key="depth_string", label = "Depth String", default = "Y %.2f", type = "input", validation_callback = pattern_validation },
    { key="time_string", label = "Time String", default = "%s", type = "input", validation_callback = pattern_validation },
    { key="hits_string", label = "Hits String", default = "%1d Hits", type = "input", validation_callback = pattern_validation },
    { key="hit_string", label = "Hit String", default = "%1d Hit", type = "input", validation_callback = pattern_validation },
    { key="polymorph_hits_string", label = "Polymorph Hits String", default = "%1d Hits (+%1d)", type = "input", validation_callback = pattern_validation },
    { key="polymorph_hit_string", label = "Polymorph Hit String", default = "%1d Hit (+%1d)", type = "input", validation_callback = pattern_validation },
    { key="separator", label = "Separator", default = " - ", type = "input", validation_callback = pattern_validation },
    { key="hit_message_string", label = "Hit Message String", default = "You were hit for %.3f damage!", type = "input", validation_callback = pattern_validation },
    { key="ghost_string", label = "Ghost state", default = "Ghost state: %s", type = "input", validation_callback = pattern_validation },
    { key="world_string", label = "World string", default = "%s", type = "input", validation_callback = pattern_validation },
    { key="orbstring", label = "Orb string", default = "%s" , type = "input", validation_callback = pattern_validation },
} );

local next_id = gokiui.next_id;
local reset_id = gokiui.reset_id;

function do_gui()
    reset_id();
    GuiStartFrame( gui );
    screen_width, screen_height = GuiGetScreenDimensions( gui );
    gokiui.parse_mod_settings();
    if not GameIsInventoryOpen() then
        GuiOptionsAdd( gui, GUI_OPTION.NoPositionTween );
        GuiLayoutBeginVertical( gui, 5, 15 );
        if is_panel_open then
            GuiBeginScrollContainer( gui, next_id(), 0, 0, 400, 200, false );
                GuiLayoutBeginVertical( gui, 0, 0 );
                    GuiColorSetForNextWidget( gui, 0.5, 0.5, 0.5, 1.0 );
                    GuiOptionsAddForNextWidget( gui, GUI_OPTION.TextRichRendering );
                    GuiText( gui, 0, 0, "UI Timer / Hits Options" );
                    GuiLayoutBeginHorizontal( gui, 0, 0 );

                        gokiui.do_gui();

                    GuiLayoutEnd( gui );
                GuiLayoutEnd( gui );
            GuiEndScrollContainer( gui );
        end
        GuiLayoutEnd( gui );
        GuiOptionsRemove( gui, GUI_OPTION.NoPositionTween );
    end

    local gx = ModSettingGet("ui_timer_hits.gui_x" );
    local gy = ModSettingGet("ui_timer_hits.gui_y" );
    local text = "";
    local player = ( EntityGetWithTag( "player_unit" ) or {} )[1];
    if player == nil then
        player = ( find_polymorphed_players() or {} )[1];
    end
    if player ~= nil then
        local x, y = EntityGetTransform( player );
        id_offset = 0;

        local is_inventory_open = false;
        if GameHasFlagRun( "gkbrkn_config_menu_open" ) or GameIsInventoryOpen() then
            is_inventory_open = true;
        end
        if is_inventory_open then
            gx = ModSettingGet("ui_timer_hits.inventory_gui_x" );
            gy = ModSettingGet("ui_timer_hits.inventory_gui_y" );
        end

        if ModSettingGet( "ui_timer_hits.show_while_in_inventory" ) == true or not is_inventory_open then
            local entries = {};

            if ModSettingGet( "ui_timer_hits.show_time" ) then
                --if USE_GAME_FRAMES_FOR_TIMER then
                --    text = "Time: "..math.floor( GameGetFrameNum() / 60 ) .. " ";
                --end
                table.insert( entries, safe_string_format( ModSettingGet( "ui_timer_hits.time_string"), StatsGetValue( "playtime_str" ) ) );
            end
            if ModSettingGet( "ui_timer_hits.show_hits" ) then
                --local hit_count = EntityGetVariableNumber( player, "ui_timer_hits_total_hits", 0 );
                local hit_count = tonumber( GlobalsGetValue( "ui_timer_hits_player_hits", "0" ) );
                local poly_hit_count = tonumber( GlobalsGetValue( "ui_timer_hits_poly_player_hits", "0" ) );
                if ModSettingGet( "ui_timer_hits.include_polymorphed_hits" ) then
                    if hit_count == 1 then
                        table.insert( entries, safe_string_format( ModSettingGet( "ui_timer_hits.polymorph_hit_string" ), hit_count, poly_hit_count ) );
                    else
                        table.insert( entries, safe_string_format( ModSettingGet( "ui_timer_hits.polymorph_hits_string" ), hit_count, poly_hit_count ) );
                    end
                else
                    if hit_count == 1 then
                        table.insert( entries, safe_string_format( ModSettingGet( "ui_timer_hits.hit_string" ), hit_count, poly_hit_count ) );
                    else
                        table.insert( entries, safe_string_format( ModSettingGet( "ui_timer_hits.hits_string" ), hit_count, poly_hit_count ) );
                    end
                end
            end
            if ModSettingGet( "ui_timer_hits.show_position" ) then
                table.insert( entries, safe_string_format( ModSettingGet( "ui_timer_hits.position_string" ),  x ) );
            end
            if ModSettingGet( "ui_timer_hits.show_depth" ) then
                table.insert( entries, safe_string_format( ModSettingGet( "ui_timer_hits.depth_string" ), y  ) );
            end
            
            if ModSettingGet( "ui_timer_hits.show_orbs_needed" ) then
                local needed = ""
                local newgame_n = tonumber( SessionNumbersGetValue("NEW_GAME_PLUS_COUNT") )
                local min_orbs = 5
                local max_orbs = 10
                if (newgame_n >= 1) then
                    min_orbs = min_orbs + newgame_n
                end

                if (min_orbs >= 12) then
                    max_orbs = 32
                end
                
                needed = min_orbs .. " to " .. max_orbs .. " orbs for NG+" .. newgame_n+1
                
                if (min_orbs == 10) then
                    needed = "10"
                end
                if (min_orbs == 11) then
                    needed = "12"
                end
                if (min_orbs == 33) then
                    needed = "Welcome to NG+28"
                end
                table.insert( entries, safe_string_format( ModSettingGet( "ui_timer_hits.orbstring" ), needed ) );
            end
            
            if ModSettingGet( "ui_timer_hits.show_world" ) then
                local world = "";
                local width = 70*512;
                local newgame_n = tonumber( SessionNumbersGetValue("NEW_GAME_PLUS_COUNT") )
                if ( newgame_n >= 1 ) then
                    width = 64*512;
                end
                
                if ( ModIsEnabled("nightmare") ) then
                    width = 64*512;
                end
                local offset = width/2;
                if ( x < offset and x > -1*offset) then
                    world = "Main World";
                else
                    if ( x > offset) then
                        world = "East " .. math.floor((x+offset)/width);
                    else
                        world = "West " .. math.floor(math.abs((x-offset)/width));
                    end
                end
                table.insert( entries, safe_string_format( ModSettingGet( "ui_timer_hits.world_string" ), world  ) );
            end
            
            if ModSettingGet("ui_timer_hits.show_ghost") then
                local g_state = "";
                local message = ""
                local worldstateEntity = GameGetWorldStateEntity();
                local world_state_component = EntityGetFirstComponentIncludingDisabled(worldstateEntity, "WorldStateComponent");
                local apparitions_per_level = ComponentGetValue2(world_state_component, "apparitions_per_level");
                
                if table.getn(apparitions_per_level) < 1 then
                    g_state = "No state yet";
                else
                    if apparitions_per_level[1] == 2 then 
                    message = " ominous candles"
                    end
                    if apparitions_per_level[1] == 3 then 
                    message = " ghost spawning"
                    end
                    if apparitions_per_level[1] == 4 then 
                    message = " ghost has spawned"
                    end
                    g_state = apparitions_per_level[1];
                end
                table.insert(entries, safe_string_format( ModSettingGet( "ui_timer_hits.ghost_string" ), g_state .. message ));
            end

            for index,entry in ipairs( entries ) do
                text = text .. entry;
                if index ~= #entries then
                    text = text .. ModSettingGet( "ui_timer_hits.separator" );
                end
            end
        end
    end
    GuiLayoutBeginVertical( gui, 0, 0 );
    GuiColorSetForNextWidget( gui, 1.0, 1.0, 1.0, ModSettingGet( "ui_timer_hits.visibility" ) );
    if GuiButton( gui, next_id(), gx, gy, text ) then
        is_panel_open = not is_panel_open;
    end
    GuiLayoutEnd( gui );
end

if gui then
    async_loop(function()
        if gui then
            local status, err = pcall( do_gui );
            if err then
                GamePrint("Goki Says: PLEASE LET ME KNOW ABOUT THIS");
                GamePrint(err);
                print("Goki Says: PLEASE LET ME KNOW ABOUT THIS");
                print(err);
                print_error("Goki Says: PLEASE LET ME KNOW ABOUT THIS");
                print_error(err);
            end
        end
        wait( 0 );
    end);
end
