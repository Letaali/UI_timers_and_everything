dofile_once( "mods/ui_timer_hits/files/lib/variables.lua" );

last_sound_played = 0;

function damage_received( damage, message, entity_thats_responsible, is_fatal  )
    local entity = tonumber( GetUpdatedEntityID() );
    local counted_hit = false;
    if tonumber( entity_thats_responsible ) == 0 then
        if ModSettingGet( "ui_timer_hits.include_environmental_hits" ) then counted_hit = true; end
    elseif tonumber( entity_thats_responsible ) == entity then
        if ModSettingGet( "ui_timer_hits.include_self_damage_hits" ) then counted_hit = true; end
    else
        counted_hit = true;
    end
    -- If damage would be negative and counted, but we don't include negative damage, reset counted to false
    if counted_hit and damage < 0 and ModSettingGet( "ui_timer_hits.include_negative_damage" ) ~= true then counted_hit = false; end
    if counted_hit then
        local current_hits = tonumber( GlobalsGetValue( "ui_timer_hits_player_hits", "0" ) );
        GlobalsSetValue( "ui_timer_hits_player_hits", tostring( current_hits + 1 ) );
        --EntityAdjustVariableNumber( entity, "ui_timer_hits_player_hits", 0, function( value ) return tonumber( value ) + 1 end );
        if ModSettingGet( "ui_timer_hits.play_sound_on_hit" ) then
            local now = GameGetFrameNum();
            if now - last_sound_played >= ModSettingGet( "ui_timer_hits.time_between_sounds" ) then
                last_sound_played = now;
                local x, y = EntityGetTransform( entity );
                for i=1,math.min( ModSettingGet( "ui_timer_hits.sound_volume" ), 10 ) do
                    GamePlaySound( "data/audio/Desktop/animals.snd", "animals/mine/beep", x, y );
                end
            end
        end
        if ModSettingGet( "ui_timer_hits.show_hit_message" ) then
            GamePrint( string.format( ModSettingGet( "ui_timer_hits.hit_message_string" ), damage * 25, GameTextGetTranslatedOrNot( message ) ) );
        end
    end
end
