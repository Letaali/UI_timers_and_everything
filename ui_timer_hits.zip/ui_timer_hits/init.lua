dofile_once( "mods/ui_timer_hits/files/lib/helper.lua");
dofile_once( "mods/ui_timer_hits/files/lib/variables.lua");

function OnWorldPreUpdate()
    if INCLUDE_POLYMORPHED_HITS then
        for _,player in pairs( find_polymorphed_players() or {} ) do
            if EntityGetVariableNumber( player, "ui_timer_poly_player", 0 ) == 0 then
                EntitySetVariableNumber( player, "ui_timer_poly_player", 1 );
                EntityAddComponent( player, "LuaComponent", {
                    script_damage_received="mods/ui_timer_hits/files/scripts/poly_player_damage_received.lua"
                });
            end
        end
    end
end

function OnPlayerSpawned( player_entity )
    EntityLoad('mods/ui_timer_hits/files/gui/container.xml');
    local init_check_flag = "ui_timer_hits_init";
    if GameHasFlagRun( init_check_flag ) == false then
        GameAddFlagRun( init_check_flag );
        EntityAddComponent( player_entity, "LuaComponent", {
            script_damage_received="mods/ui_timer_hits/files/scripts/player_damage_received.lua"
        });
    end
end
